# LVT uzdevums
## _Picas programma_

_Programmas apraksts_: Varat izvēlēties, kas esat - klients vai darbinieks;
lai ieiet Darbienieka akaunat ir jaievad logins un parole 

Login: Admin

Parole: Admin123

darbinieks var apstities pasutijumus un komentarus ka ari izdzes tos 
klients var pac salasit sev picu no piedavatajiemvariantiem var izveleties:

izmeru, picas veidu, merci, un piedevas.

tad var noformet pasutijumu, tad var apskatit pasutijumu un uzrakstit kometaru  

- [x] izveidota programma
- [x] ieladeta github
- [x] pievienoti atteli
- [ ] darbiniekam pieliku papildus funkcijas
- [x] izlaboju dazas kludas
- [ ] programma pievienota jframe funkciolitate :sweat_smile:
