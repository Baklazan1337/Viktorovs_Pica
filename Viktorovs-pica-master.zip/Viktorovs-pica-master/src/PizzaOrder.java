

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


 public class PizzaOrder { 
	
	  
	   static ArrayList<String> selectedMerce = new ArrayList<>();
	   static ArrayList<String> selectedSizes = new ArrayList<>();
	   static ArrayList<String> selectedPizzas = new ArrayList<>();
	   
	 
	    public static void main(String[] args) throws IOException { 
	    	 SwingUtilities.invokeLater(new Runnable() {
	             public void run() {
	        SwitchLogin();
	             }    
	   });    

	    	 }

//------------------------------------------------------------------------------------------------------


     public static void SwitchLogin() {
		
    JFrame f= new JFrame("Luxury Pizza");  
    f.getContentPane().setBackground( Color.BLACK );
  
//---------label 
    
    JLabel l1, l2;  
    l1=new JLabel("Luxury Pizza");  
    l1.setBounds(40,30, 1000,90);
    l1.setForeground(Color.YELLOW);
    l1.setFont(new Font("Arial Black", Font.PLAIN, 60));

    
    l2=new JLabel("Izvelies kas tu esi?");  
    l2.setBounds(140,100, 190,60);
    l2.setForeground(Color.WHITE);
    l2.setFont(new Font("Calibri", Font.BOLD, 20));
    Icon icon = UIManager.getIcon("OptionPane.informationIcon");
    l2.setIcon(icon);

//---------Button    
    
    Color c1 = new Color(178, 0, 255);  
    Color c2 = new Color(177, 0, 0);
   
   
    JButton Button1 = new JButton("Klients");
    Button1.setBounds(125, 170, 120, 30);
    Button1.setFont(new Font("Arial Black", Font.PLAIN, 14));
    Button1.setBackground(c1);
    Button1.setForeground(Color.black);
    Button1.addActionListener(new ActionListener() {
    	  
    	   public void actionPerformed(ActionEvent e) {
    		   Klients();
			f.dispose();    
    	   }
    	});
    
    
    JButton Button2 = new JButton("Darbinieks");
    Button2.setBounds(260, 170, 120, 30);
    Button2.setFont(new Font("Arial Black", Font.PLAIN, 14));
    Button2.setBackground(c1);
    Button2.setForeground(Color.black);
    Button2.addActionListener(new ActionListener() {
  	  
 	   public void actionPerformed(ActionEvent e) {
 		   Darbinieks();;
		f.dispose();    
 	   }
 	});
    
    JButton Button3 = new JButton("Beigt");
    Button3.setBounds(215, 220, 70, 30);
    Button3.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button3.setBackground(c2);
    Button3.setForeground(Color.black);
    Button3.addActionListener(new ActionListener() {
    	 
		public void actionPerformed(ActionEvent event) {
			System.exit(0);
		}
	});
    
    
    f.add(Button1); f.add(Button2); f.add(Button3);
    f.add(l1); f.add(l2); 
    f.setSize(500,300);  
    f.setLayout(null);  
    f.setVisible(true);  
    
}  

//------------------------------------------------------------------------------------------------------

 public static void Klients() {
	
	
	JFrame f2= new JFrame("Luxury Pizza");  
    f2.getContentPane().setBackground( Color.BLACK );
  
//---------label      
    
    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9;
    l1=new JLabel("Luxury Pizza");  
    l1.setBounds(380,30, 1000,100);
    l1.setForeground(Color.YELLOW);
    l1.setFont(new Font("Arial Black", Font.PLAIN, 80));
   

    
    Color c1 = new Color(236, 1, 255);
   
    l2=new JLabel("Izvelies picas izmeru picai");  
    l2.setBounds(70,120, 1000,100);
    l2.setForeground(c1);
    l2.setFont(new Font("Cascadia Mono", Font.PLAIN, 20));
    
    l3=new JLabel("Izvelies picas veidu");  
    l3.setBounds(350,120, 1000,100);
    l3.setForeground(c1);
    l3.setFont(new Font("Cascadia Mono", Font.PLAIN, 20));
 
    l4=new JLabel("Izvelies merci picai");  
    l4.setBounds(630,120, 1000,100);
    l4.setForeground(c1);
    l4.setFont(new Font("Cascadia Mono", Font.PLAIN, 20));
    
    l5=new JLabel("Vai kau to Gribi 2X");  
    l5.setBounds(910,120, 1000,100);
    l5.setForeground(c1);
    l5.setFont(new Font("Cascadia Mono", Font.PLAIN, 20));
    
    l6=new JLabel("Jusu Vards:");  
    l6.setBounds(65,310, 1000,100);
    l6.setForeground(c1);
    l6.setFont(new Font("Arial Black", Font.PLAIN, 13));

    l7=new JLabel("Jusu telefons:");  
    l7.setBounds(45,360, 1000,100);
    l7.setForeground(c1);
    l7.setFont(new Font("Arial Black", Font.PLAIN, 13));
    
    l8=new JLabel("Jusu adrese:");  
    l8.setBounds(55,410, 1000,100);
    l8.setForeground(c1);
    l8.setFont(new Font("Arial Black", Font.PLAIN, 13));
    
    l9=new JLabel("Jusu emails:");  
    l9.setBounds(55,460, 1000,100);
    l9.setForeground(c1);
    l9.setFont(new Font("Arial Black", Font.PLAIN, 13));
    
//---------list 

   

    
    DefaultListModel<String> listt = new DefaultListModel<>();    
    listt.addElement("20cm - 5€");  
    listt.addElement("30cm - 8€");  
    listt.addElement("45cm - 13€");  
    listt.addElement("55cm - 18€"); 
   
    
    JList<String> list = new JList<>(listt);  
    list.setBounds(70,200, 150,200);  
    list.setBackground(Color.black);
    list.setForeground(Color.white);
    list.setFont(new Font("Cascadia Mono", Font.PLAIN, 20));
    list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    
    DefaultListModel<String> listt2 = new DefaultListModel<>();    
    listt2.addElement("Margaria");  
    listt2.addElement("Vezuvi");  
    listt2.addElement("Studentu");  
    listt2.addElement("Havajas");  
    listt2.addElement("Parlocita");  
    listt2.addElement("4 Sieru");  
    listt2.addElement("4 Sezonu");  
    listt2.addElement("Sēņu"); 
    listt2.addElement("Grieķu"); 
    
    
    JList<String> list2 = new JList<>(listt2);  
    list2.setBounds(350,200, 150,300);  
    list2.setBackground(Color.black);
    list2.setForeground(Color.white);
    list2.setFont(new Font("Cascadia Mono", Font.PLAIN, 20));
    list2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    
    DefaultListModel<String> listt3 = new DefaultListModel<>();    
    listt3.addElement("Ketčups");  
    listt3.addElement("Majoneze");  
    listt3.addElement("BBQ");  
    listt3.addElement("Gurķu majoneze");  
    listt3.addElement("Papriku majoneze");  
    listt3.addElement("Sineps");  
    listt3.addElement("Sieru merce");  
    listt3.addElement("Ķiploku merce"); 
    listt3.addElement("Saldskaba merce"); 
    
    JList<String> list3 = new JList<>(listt3);  
    list3.setBounds(630,200, 200,300);  
    list3.setBackground(Color.black);
    list3.setForeground(Color.white);
    list3.setFont(new Font("Cascadia Mono", Font.PLAIN, 20));
    list3.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//---------RB    
    
   
    JRadioButton Siers, Merce, Desas, Senes, Ananasu, Šķiņķi;
    
 
    Siers=new JRadioButton("2xSiers - 0.50€");
    Siers.setBounds(910,200, 150,40);
    Siers.setBackground(Color.black);
    Siers.setForeground(Color.white); 
  
    
    Merce=new JRadioButton("2xMerce - 0.20€");
    Merce.setBounds(910,240, 150,40);
    Merce.setBackground(Color.black);
    Merce.setForeground(Color.white);

    
    Desas=new JRadioButton("2xDesas - 0.50€");
    Desas.setBounds(910,280, 150,40);
    Desas.setBackground(Color.black);
    Desas.setForeground(Color.white);
 
    
    Senes=new JRadioButton("2xSenes - 0.50€");
    Senes.setBounds(910,320, 150,40);
    Senes.setBackground(Color.black);
    Senes.setForeground(Color.white);

    
    Ananasu=new JRadioButton("2xAnanasu - 0.50€");
    Ananasu.setBounds(910,360, 150,40);
    Ananasu.setBackground(Color.black);
    Ananasu.setForeground(Color.white);
  
    
    Šķiņķi=new JRadioButton("2XŠķiņķi - 0.50€");
    Šķiņķi.setBounds(910,400, 150,40);
    Šķiņķi.setBackground(Color.black);
    Šķiņķi.setForeground(Color.white);
   
//----------------JFLield
    
    JTextField klientaVards = new JTextField(20);
    klientaVards.setBounds(155, 350, 150, 20);
    klientaVards.setForeground(Color.black);
    
    JTextField telefons = new JTextField(20);
    telefons.setBounds(155, 400, 150, 20);
    telefons.setForeground(Color.black);

    JTextField adrese = new JTextField(20);
    adrese.setBounds(155, 450, 150, 20);
    adrese.setForeground(Color.black);

    JTextField email = new JTextField(20);
    email.setBounds(155, 500, 150, 20);
    email.setForeground(Color.black);    

    
//---------Button 
    
    Color c2 = new Color(177, 0, 0);
    
    JButton Button2 = new JButton("Atpakaļ");
    Button2.setBounds(1080, 510, 90, 30);
    Button2.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button2.setBackground(Color.orange);
    Button2.setForeground(Color.black);
    Button2.addActionListener(new ActionListener() {
    	  
  	   public void actionPerformed(ActionEvent e) {
  		   SwitchLogin();
		 f2.dispose();    
  	   }
  	});
    
    JButton Button3 = new JButton("Beigt");
    Button3.setBounds(1190, 510, 70, 30);
    Button3.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button3.setBackground(c2);
    Button3.setForeground(Color.black);
    Button3.addActionListener(new ActionListener() {
    	 
		public void actionPerformed(ActionEvent event) {
			System.exit(0);
		}
	});
    
    
    
    
    JButton Button1 = new JButton("Veikt Pasutijumu");
    Button1.setBounds(905, 510, 150, 30);
    Button1.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button1.setBackground(Color.green);
    Button1.setForeground(Color.black);
    Button1.addActionListener(new ActionListener() {
    	 
		public void actionPerformed(ActionEvent event) {
				f2.dispose();
				pasutijums();
                String piedevas = "";
				double cenaPicai = 0.0;
				 String lielums2 = ""; 
				
				if(Šķiņķi.isSelected()) {
			        piedevas = "Šķiņķi, ";
			        cenaPicai+=0.50;
			    }
				if(Siers.isSelected()) {
			        piedevas += "Siers, ";
			        cenaPicai+=0.50;
			    }
				if(Merce.isSelected()) {
			        piedevas += "Merce, ";
			        cenaPicai+=0.50;
			    }
				if(Ananasu.isSelected()) {
			        piedevas += "Ananasu, ";
			        cenaPicai+=0.50;
			    }
				if(Desas.isSelected()) {
			        piedevas += "Desas, ";
			        cenaPicai+=0.50;
			    }
				if(Senes.isSelected()) {
			        piedevas += "Senes, ";
			        cenaPicai+=0.50;
			    }
				String merce = list3.getSelectedValue();
				String lielums = list.getSelectedValue();
                String Nosaukums = list2.getSelectedValue();
                String KliVards = klientaVards.getText();
                String KliTel = telefons.getText();
                String KliAdrese = adrese.getText();
                String KliEmail = email.getText();
                if (lielums != null && Nosaukums != null && merce != null) {
                    selectedSizes.add(lielums);
                    selectedPizzas.add(Nosaukums);
                    selectedMerce.add(merce);
                    

                }    
                
                if(lielums.equals("20cm - 5€")) {
                	lielums2 = "20cm";
                	cenaPicai+=5.0;
                }
                if(lielums.equals("30cm - 8€")) {
                	lielums2 = "40cm";
                	cenaPicai+=8.0;
                }
                if(lielums.equals("45cm - 13€")) {
                	lielums2 = "45cm";
                	cenaPicai+=13.0;
                }
                if(lielums.equals("55cm - 18€")) {
                	lielums2 = "55cm";
                	cenaPicai+=18.0;
                }
                        FileWriter writer;
                        FileWriter writer2;
						try {
							writer = new FileWriter("PicasInfo.txt", true);
							writer2 = new FileWriter("PicasInfoKlients.txt", true);
							writer.write("------Ceks------\n");
							writer.write("Izmers: "+lielums2+"\n");
							writer.write("Nosaukums: "+Nosaukums+"\n");
							writer.write("Merce: "+merce+"\n");
							writer.write("Piedevas "+piedevas+"\n");
							writer.write("Cena: "+cenaPicai+"\n");
							writer.write("Klienta info---\n");
							writer.write("Klienta vards: "+KliVards+"\n");
							writer.write("Telefons: "+KliTel+"\n");
							writer.write("Adrese: "+KliAdrese+"\n");
							writer.write("Emails: "+KliEmail+"\n");
	                        writer.close();
	                        writer2.write("------Ceks------\n");
							writer2.write("Izmers: "+lielums2+"\n");
							writer2.write("Nosaukums: "+Nosaukums+"\n");
							writer2.write("Merce: "+merce+"\n");
							writer2.write("Piedevas "+piedevas+"\n");
							writer2.write("Cena: "+cenaPicai+"\n");
	                        writer2.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
                        
                        
		}
	});
        
    
    f2.add(l6); f2.add(l7); f2.add(l8); f2.add(l9);
    f2.add(klientaVards); f2.add(telefons); f2.add(adrese); f2.add(email);
    f2.add(Siers);f2.add(Merce);f2.add(Desas);f2.add(Senes);f2.add(Ananasu);f2.add(Šķiņķi);
    f2.add(list); f2.add(list2); f2.add(list3); 
    f2.add(l1); f2.add(l2); f2.add(l3); f2.add(l4); f2.add(l5);
    f2.add(Button3);f2.add(Button2);f2.add(Button1);
    f2.setSize(1300,600);  
    f2.setLayout(null);  
    f2.setVisible(true);
    
    }



//------------------------------------------------------------------------------------------------------

	 
   public static void Darbinieks() {  
    
//---------Label	
	
	JFrame f3= new JFrame("Luxury Pizza");  
    f3.getContentPane().setBackground( Color.BLACK );
    
    JLabel l1, l2, l3; 
    l1=new JLabel("Luxury Pizza");  
    l1.setBounds(55,30, 1000,40);
    l1.setForeground(Color.YELLOW);
    l1.setFont(new Font("Arial Black", Font.PLAIN, 40));

    
    l2=new JLabel("User name");  
    l2.setBounds(50,100, 190,60);
    l2.setForeground(Color.WHITE);
    l2.setFont(new Font("Calibri", Font.BOLD, 14));
    Icon icon = UIManager.getIcon("OptionPane.informationIcon");
    l2.setIcon(icon);
    
    l3=new JLabel("Password");  
    l3.setBounds(50,100, 190,190);
    l3.setForeground(Color.WHITE);
    l3.setFont(new Font("Calibri", Font.BOLD, 14));
    l3.setIcon(icon);
    

//---------TextField   
    
    
    JTextField usernameField = new JTextField(20);
    usernameField.setBounds(155, 119, 150, 20);
    usernameField.setForeground(Color.black);
    
    JPasswordField passwordField = new JPasswordField(20);
    passwordField.setBounds(155, 182, 150, 20);
    passwordField.setForeground(Color.black);
     
    
//---------Button   
    
    
    Color c2 = new Color(177, 0, 0);
    
    JButton loginButton = new JButton("Login");
    loginButton.setBounds(30, 220, 70, 30);
    loginButton.setFont(new Font("Arial Black", Font.PLAIN, 12));
    loginButton.setBackground(Color.green);
    loginButton.setForeground(Color.black);
    loginButton.addActionListener(new ActionListener() {
       
        public void actionPerformed(ActionEvent e) {
        
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (username.equals("Admin") && password.equals("Admin123")) {
                
                DarbiniekMenu();
				f3.dispose();
                
            	
            } else {
            	
            	f3.dispose();
            	JFrame lf= new JFrame("ERROR");  
                lf.getContentPane().setBackground( Color.BLACK );
                
                
            	JLabel l4=new JLabel("Nepareizi ievadits User vai Password");  
                l4.setBounds(30,40, 300,30);
                l4.setForeground(Color.WHITE);
                l4.setFont(new Font("Calibri", Font.BOLD, 15));
                
                JButton Button = new JButton("Atpakaļ");
                Button.setBounds(100, 70, 90, 30);
                Button.setFont(new Font("Arial Black", Font.PLAIN, 12));
                Button.setBackground(Color.orange);
                Button.setForeground(Color.black);
                Button.addActionListener(new ActionListener() {
               	 
            		public void actionPerformed(ActionEvent event) {
            			
            			Darbinieks();
						lf.dispose();
            		}
            	});
                
                lf.add(Button);
                lf.add(l4);
                lf.setSize(300,200);  
                lf.setLayout(null);  
                lf.setVisible(true);
            }
        }
    });
  

    
    
    JButton Button2 = new JButton("Atpakaļ");
    Button2.setBounds(145, 220, 90, 30);
    Button2.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button2.setBackground(Color.orange);
    Button2.setForeground(Color.black);
    Button2.addActionListener(new ActionListener() {
    	  
  	   public void actionPerformed(ActionEvent e) {
  		   SwitchLogin();
		 f3.dispose();    
  	   }
  	});
    
    JButton Button3 = new JButton("Beigt");
    Button3.setBounds(280, 220, 70, 30);
    Button3.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button3.setBackground(c2);
    Button3.setForeground(Color.black);
    Button3.addActionListener(new ActionListener() {
    	 
		public void actionPerformed(ActionEvent event) {
			System.exit(0);
		}
	});
    
   
  
    f3.add(l1); f3.add(l2); f3.add(l3);  f3.add(usernameField); f3.add(passwordField);
    f3.add(Button3);f3.add(Button2);f3.add(loginButton);
    f3.setSize(400,300);  
    f3.setLayout(null);  
    f3.setVisible(true);

	
}

	
	
//------------------------------------------------------------------------------------------------------

//---------Label

public static void DarbiniekMenu() {
	JFrame f7= new JFrame("Luxury Pizza");  
    f7.getContentPane().setBackground( Color.BLACK );
    
    JLabel l1;
    l1=new JLabel("Labdien Admin");  
    l1.setBounds(80,30, 1000,60);
    l1.setForeground(Color.YELLOW);
    l1.setFont(new Font("Arial Black", Font.PLAIN, 40));

//---------Button  
    
    Color c1 = new Color(177, 0, 0);
    
    JButton Button1 = new JButton("Beigt");
    Button1.setBounds(400, 320, 70, 30);
    Button1.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button1.setBackground(c1);
    Button1.setForeground(Color.black);
    Button1.addActionListener(new ActionListener() {
  	  
   	   public void actionPerformed(ActionEvent e) {
   		  System.exit(0);	   
   	   }
   	});
    
    JButton Button2 = new JButton("Atpakaļ");
    Button2.setBounds(280, 320, 100, 30);
    Button2.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button2.setBackground(Color.orange);
    Button2.setForeground(Color.black);
    Button2.addActionListener(new ActionListener() {
  	  
   	   public void actionPerformed(ActionEvent e) {
   		SwitchLogin();
		f7.dispose();	   
   	   }
   	});
    
    JButton Button3 = new JButton("Apskatit pasutijumu");
    Button3.setBounds(160, 100, 170, 30);
    Button3.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button3.setBackground(Color.green);
    Button3.setForeground(Color.black);
    Button3.addActionListener(new ActionListener() {
        
        public void actionPerformed(ActionEvent e) {
        	BufferedReader br = null;
		    try {
				br = new BufferedReader(new FileReader("PicasInfo.txt"));
			

            String izvade;
            String dati = "";

				while((izvade=br.readLine())!=null) {
				    dati+=izvade+"\n";
		}

            JTextArea textArea = new JTextArea(dati);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(300, 300));
            JOptionPane.showMessageDialog(null, scrollPane,"PASUTIJUMI",JOptionPane.PLAIN_MESSAGE);

            
				br.close();
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}
        	
        }
    });
    
    Color c2 = new Color(0, 150, 255);
    
    JButton Button4 = new JButton("Apskatit Komentaus");
    Button4.setBounds(160, 150, 170, 30);
    Button4.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button4.setBackground(c2);
    Button4.setForeground(Color.black);
    Button4.addActionListener(new ActionListener() {
        
        public void actionPerformed(ActionEvent e) {
        	BufferedReader br = null;
		    try {
				br = new BufferedReader(new FileReader("Komentari.txt"));
			

            String izvade;
            String dati = "";

				while((izvade=br.readLine())!=null) {
				    dati+=izvade+"\n";
		}

            JTextArea textArea = new JTextArea(dati);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(300, 300));
            JOptionPane.showMessageDialog(null, scrollPane,"PASUTIJUMI",JOptionPane.PLAIN_MESSAGE);

            
				br.close();
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}
        }
    });
    
    JButton Button5 = new JButton("Dzest Komentaus");
    Button5.setBounds(160, 200, 170, 30);
    Button5.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button5.setBackground(Color.red);
    Button5.setForeground(Color.black);
    Button5.addActionListener(new ActionListener() {
        
        public void actionPerformed(ActionEvent e) {
        	 try {
        		 JFrame lf= new JFrame("ERROR");  
                 lf.getContentPane().setBackground( Color.black );
        		 
                 File file = new File("Komentari.txt");
                 FileWriter writer = new FileWriter(file);
                 writer.write("");
                 writer.close();
                 JOptionPane.showMessageDialog(lf, "Komentari veiksmigi izdzesti", "Komentari", JOptionPane.INFORMATION_MESSAGE);
             } catch (IOException ex) {
            	 JFrame lf= new JFrame("ERROR");  
                 lf.getContentPane().setBackground( Color.black );
                 
                 JOptionPane.showMessageDialog(lf, "Iznaca kluda dzesot komentarus", "ERROR", JOptionPane.ERROR_MESSAGE);
                 ex.printStackTrace();
             }
        }
    });
    
    
    JButton Button6 = new JButton("Dzest Pasutijumus");
    Button6.setBounds(160, 250, 170, 30);
    Button6.setFont(new Font("Arial Black", Font.PLAIN, 12));
    Button6.setBackground(Color.red);
    Button6.setForeground(Color.black);
    Button6.addActionListener(new ActionListener() {
        
        public void actionPerformed(ActionEvent e) {
        	 try {
        		 JFrame lf= new JFrame("ERROR");  
                 lf.getContentPane().setBackground( Color.black );
        		 
                 File file = new File("PicasInfo.txt");
                 FileWriter writer = new FileWriter(file);
                 writer.write("");
                 writer.close();
                 JOptionPane.showMessageDialog(lf, "Pasutijuni veiksmigi izdzesti", "Komentari", JOptionPane.INFORMATION_MESSAGE);
             } catch (IOException ex) {
            	 JFrame lf= new JFrame("ERROR");  
                 lf.getContentPane().setBackground( Color.black );
                 
                 JOptionPane.showMessageDialog(lf, "Iznaca kluda dzesot Pasutijumus", "ERROR", JOptionPane.ERROR_MESSAGE);
                 ex.printStackTrace();
             }
        }
    });
    
    f7.add(l1); f7.add(Button1); f7.add(Button2); f7.add(Button3); f7.add(Button4); f7.add(Button5); f7.add(Button6);
    f7.setSize(500,400);  
    f7.setLayout(null);  
    f7.setVisible(true);
 }


//------------------------------------------------------------------------------------------------------

//---------Label

public static void Komentari(){
	JFrame f7= new JFrame("Luxury Pizza");  
  f7.getContentPane().setBackground( Color.BLACK );
  
  JLabel l1;
  l1=new JLabel("Raksti Komentaru!!!");  
  l1.setBounds(60,30, 1000,60);
  l1.setForeground(Color.YELLOW);
  l1.setFont(new Font("Arial Black", Font.PLAIN, 25));

  
//---------Button
  
  Color c1 = new Color(177, 0, 0);
  
  JButton Button1 = new JButton("Beigt");
  Button1.setBounds(300, 220, 70, 30);
  Button1.setFont(new Font("Arial Black", Font.PLAIN, 12));
  Button1.setBackground(c1);
  Button1.setForeground(Color.black);
  Button1.addActionListener(new ActionListener() {
	  
 	   public void actionPerformed(ActionEvent e) {
 		  System.exit(0);	   
 	   }
 	});
  
  JButton Button2 = new JButton("Atpakaļ");
  Button2.setBounds(190, 220, 100, 30);
  Button2.setFont(new Font("Arial Black", Font.PLAIN, 12));
  Button2.setBackground(Color.orange);
  Button2.setForeground(Color.black);
  Button2.addActionListener(new ActionListener() {
	  
 	   public void actionPerformed(ActionEvent e) {
 		SwitchLogin();
		f7.dispose();	   
 	   }
 	});
  
 
  
//---------Field
  
  JTextField komentars = new JTextField(20);
  komentars.setBounds(90, 120, 200, 30);
  komentars.setForeground(Color.black);
  
  
  
  
  JButton saveButton = new JButton("Aizsutit");
  saveButton.setBounds(140, 160, 100, 30);
  saveButton.setFont(new Font("Arial Black", Font.PLAIN, 12));
  saveButton.setBackground(Color.green);
  saveButton.setForeground(Color.black);
  saveButton.addActionListener(new ActionListener() {
      
      public void actionPerformed(ActionEvent e) {
          String kom = komentars.getText();
          JOptionPane.showMessageDialog(f7, "Komentarijs ir aizsutits!!", "Komentari", JOptionPane.INFORMATION_MESSAGE);
          if (kom != null)  {
              try {
                  FileWriter writer = new FileWriter("Komentari.txt", true);
                  writer.write(kom + "\n");
                  writer.write("-----------------------\n");
                  writer.close();
              } catch (IOException ex) {
                  ex.printStackTrace();
              }
          }
      }
  });
  
  
   
  
  f7.add(l1); f7.add(saveButton);
  f7.add(komentars);
  f7.add(Button1); f7.add(Button2);
  f7.setSize(400,300);  
  f7.setLayout(null);  
  f7.setVisible(true);

}


 public static void pasutijums(){
 
 JFrame f5= new JFrame("Luxury Pizza");  
 f5.getContentPane().setBackground( Color.BLACK );
 
 JLabel l1, l2, l3, l4;
 l1=new JLabel("Luxury Pizza");  
 l1.setBounds(110,30, 1000,60);
 l1.setForeground(Color.YELLOW);
 l1.setFont(new Font("Arial Black", Font.PLAIN, 40));
 
 l2=new JLabel("Pasutijums ir pieņemts!!!");  
 l2.setBounds(110,70, 1000,60);
 l2.setForeground(Color.CYAN);
 l2.setFont(new Font("Arial Black", Font.PLAIN, 20));
 
 l3=new JLabel("Pasutijums bus gatavs pec 30-40 min");  
 l3.setBounds(112,90, 1000,60);
 l3.setForeground(Color.blue);
 l3.setFont(new Font("Arial Black", Font.PLAIN, 13));
 
 l4=new JLabel("Lai garšo un veikmigu dienu 'Luxury Pizza'!!!");  
 l4.setBounds(90,110, 1000,60);
 l4.setForeground(Color.red);
 l4.setFont(new Font("Arial Black", Font.PLAIN, 13));
 

//---------Button 
 
 Color c1 = new Color(177, 0, 0);
 
 JButton Button1 = new JButton("Beigt");
 Button1.setBounds(400, 320, 70, 30);
 Button1.setFont(new Font("Arial Black", Font.PLAIN, 12));
 Button1.setBackground(c1);
 Button1.setForeground(Color.black);
 Button1.addActionListener(new ActionListener() {
	  
	   public void actionPerformed(ActionEvent e) {	
		  File file = new File("PicasInfoKlients.txt");
          FileWriter writer2;
		try {
			writer2 = new FileWriter(file);
			writer2.write("");
	         writer2.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 System.exit(0);
	   }
	});
 
 JButton Button2 = new JButton("Atpakaļ");
 Button2.setBounds(300, 320, 90, 30);
 Button2.setFont(new Font("Arial Black", Font.PLAIN, 12));
 Button2.setBackground(Color.orange);
 Button2.setForeground(Color.black);
 Button2.addActionListener(new ActionListener() {
 	  
	   public void actionPerformed(ActionEvent e) {
		   SwitchLogin();
		 f5.dispose(); 
		  File file = new File("PicasInfoKlients.txt");
          FileWriter writer2;
		try {
			writer2 = new FileWriter(file);
			writer2.write("");
	         writer2.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		
	   }
	   }
	});
 
 
 JButton Button4 = new JButton("Uzrakstit komentaru");
 Button4.setBounds(170, 250, 170, 30);
 Button4.setFont(new Font("Arial Black", Font.PLAIN, 12));
 Button4.setBackground(Color.blue);
 Button4.setForeground(Color.black);
 Button4.addActionListener(new ActionListener() {
	  
	   public void actionPerformed(ActionEvent e) {
		   Komentari();
		 f5.dispose(); 
		  File file = new File("PicasInfoKlients.txt");
          FileWriter writer2;
		try {
			writer2 = new FileWriter(file);
			writer2.write("");
	         writer2.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   }
	});
 
 JButton Button5 = new JButton("Apskatities pasutijumu");
 Button5.setBounds(160, 200, 190, 30);
 Button5.setFont(new Font("Arial Black", Font.PLAIN, 12));
 Button5.setBackground(Color.green);
 Button5.setForeground(Color.black);
 Button5.addActionListener(new ActionListener() {
     
     public void actionPerformed(ActionEvent e) {
         try {
             StringBuilder pica = new StringBuilder();
             java.util.List<String> lines = java.nio.file.Files.readAllLines(java.nio.file.Paths.get("PicasInfoKlients.txt"));
             for (String line : lines) {
                 pica.append(line).append("\n");
             }
         	JFrame lf= new JFrame("ERROR");  
             lf.getContentPane().setBackground( Color.black );
             
             JOptionPane.showMessageDialog(lf, pica.toString(), "Pasutijums", JOptionPane.INFORMATION_MESSAGE);
                   
         } catch (IOException ex) {
             ex.printStackTrace();
         }
     }
 });
	
 f5.add(Button1); f5.add(Button2); f5.add(Button4); f5.add(Button5); 
 f5.add(l1); f5.add(l2); f5.add(l3); f5.add(l4); 
 f5.setSize(500,400);  
 f5.setLayout(null);  
 f5.setVisible(true);

 
 }
}

